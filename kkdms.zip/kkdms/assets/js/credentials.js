const teachers = [
  { name: "Abdul Sir", userId: "Abdul1998", password: "Abdul@1998" },
  { name: "Rita Ma'am", userId: "Rita123", password: "Rita@123" },
  { name: "Suman Sir", userId: "Suman456", password: "Suman@456" }
];


