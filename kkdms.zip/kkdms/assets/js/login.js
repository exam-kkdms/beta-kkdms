// Populate dropdown + prefill remembered ID
window.onload = function () {
  const dropdown = document.getElementById("userIdSelect");

  // Populate dropdown with user IDs
  teachers.forEach(teacher => {
    const option = document.createElement("option");
    option.value = teacher.userId;
    option.textContent = teacher.userId;
    dropdown.appendChild(option);
  });

  // Prefill remembered user if stored
  const rememberedUser = localStorage.getItem("rememberedUser");
  if (rememberedUser) {
    dropdown.value = rememberedUser;
    document.getElementById("rememberMe").checked = true;
  }
};

// Toggle password visibility
function togglePassword() {
  const input = document.getElementById("passwordInput");
  const icon = document.getElementById("toggleIcon");

  if (input.type === "password") {
    input.type = "text";
    icon.classList.remove("bi-eye");
    icon.classList.add("bi-eye-slash");
  } else {
    input.type = "password";
    icon.classList.remove("bi-eye-slash");
    icon.classList.add("bi-eye");
  }
}


// Login and validation
function loginUser() {
  const selectedId = document.getElementById("userIdSelect").value;
  const password = document.getElementById("passwordInput").value;
  const remember = document.getElementById("rememberMe").checked;

  const matchedUser = teachers.find(t => t.userId === selectedId && t.password === password);

  if (matchedUser) {
    // Store name for dashboard
    localStorage.setItem("loggedInName", matchedUser.name);

    // Store or clear remembered ID
    if (remember) {
      localStorage.setItem("rememberedUser", matchedUser.userId);
    } else {
      localStorage.removeItem("rememberedUser");
    }

    // Redirect to dashboard
    window.location.href = "../teacher/dashboard.html";
  } else {
    alert("Invalid ID or Password");
  }
}
