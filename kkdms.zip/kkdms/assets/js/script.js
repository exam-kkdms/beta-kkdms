// ===== Notice Modal =====
document.addEventListener("DOMContentLoaded", function () {
  const modal = document.querySelector(".modal-bg");
  const closeBtn = document.querySelector(".modal-close");

  // Auto show after login or delay
  if (modal) {
    setTimeout(() => modal.style.display = "flex", 1000);
  }

  if (closeBtn) {
    closeBtn.addEventListener("click", () => {
      modal.style.display = "none";
    });
  }
});

// ===== Spinner Control Example =====
function showSpinner(id) {
  document.getElementById(id).style.display = "block";
}
function hideSpinner(id) {
  document.getElementById(id).style.display = "none";
}

// ===== Smooth Scroll (optional enhancement) =====
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault();
    document.querySelector(this.getAttribute('href'))
      .scrollIntoView({ behavior: 'smooth' });
  });
});


